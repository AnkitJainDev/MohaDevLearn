import java.util.Scanner;


public class SquareRoot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter number :");
		int num = s.nextInt();
		double root = 1;
//		while(root*root <= num){
//			root++;
//		}
//		root--;
//		System.out.println(root);
//		System.out.println("Enter number of decimal digits ");
//		int numPlaces = s.nextInt();
//		int currentPos = 0;
//		while(currentPos <= numPlaces){
//			double stepValue = Math.pow(10, 0-currentPos);
//			while(root*root <= num){
//				root += stepValue;
//			}
//			root = root - stepValue;
//			currentPos++;
//		}	
//		System.out.println(root);
		
		double a = 0.25 + 0.5;		
		System.out.println(a);
	}

}
