import java.util.Scanner;

public class FahrenheitToCelsius {


	public static void  printValues(int minFahrenheitValue, int maxFahrenheitValue, int step){
		int currentFahrenheitValue = minFahrenheitValue;
		while(currentFahrenheitValue <= maxFahrenheitValue){
			int celsiusValue = (int)((5.0/9)*(currentFahrenheitValue - 32));
			System.out.println(currentFahrenheitValue +" "+celsiusValue);
			currentFahrenheitValue = currentFahrenheitValue + step;
		}
	}


	public static void func(int a, int b){
		//	System.out.println(first);
		System.out.println(a);
		System.out.println(b);
	}

	public static void a(){
		
		b();
		System.out.println("Inside a ");
	}

	public static void b(){
		System.out.println("Inside b ");

	}

	public static int inc(int num){
		//num++;
		return ++num;
	}
	
	
	public static void main(String[] args) {

		
		int num = 10;
		num = inc(num);
		System.out.println(num);
		
		
//		a();
//		System.out.println("Inside main ");



		//				int first = 4;
		//				int second = 5;
		//				func(first, second);
		//
		//				System.out.println(first);

		/*int a = 10;
		int b ;
		if(a < 20){
		//	int b = 30
			b = 30;
			System.out.println(b);
		}
		else{
			int b = 50;
			System.out.println(b);
		}
		System.out.println(b);*/


//		int a = 1;
//		int b = 10;
//		while(a < 10){
//
//			System.out.println(b);
//			a++;
//			b++;
//		}
//		System.out.println(a);
//
//
//		int c = 10;
//		for(int i = 1; i < 10; i++){
//			System.out.println(c);
//		}
//		System.out.println(i);


		//	System.out.println(a);

		//		Scanner s = new Scanner(System.in);		
		//		System.out.println("Enter Minimum value");
		//		int	minFahrenheitValue = s.nextInt();
		//		//	s.ne
		//		System.out.println("Enter Maximum value");
		//		int maxFahrenheitValue = s.nextInt();
		//		
		//		System.out.println("Enter step size :");
		//		int step = s.nextInt();
		//		
		//		printValues(minFahrenheitValue, maxFahrenheitValue, step);
		//			
		//		System.out.println(currentFahrenheitValue);


	}

}
