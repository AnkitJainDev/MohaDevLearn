import java.util.Scanner;


public class ArrayUse {

	public static int[] incrementArray(int[] input){
		input = new int[5];
		for(int i = 0; i < input.length; i++){
			input[i]++;
		}
		return input;
	}

	public static void main(String[] args) {

		int input[];
		input = takeInput(); // 1 2 3 4 
		
		bubbleSort(input);
		
	//	input = new int[5];
	//	System.out.println(input);
		printArray(input);
//		input = incrementArray(input);
//		printArray(input);
		//	System.out.println("Sum "+ sum(input));

	}


	public static int[] takeInput(){
		Scanner s = new Scanner(System.in);
		System.out.println("Enter size ");
		int size = s.nextInt();
		int arr[] = new int[size];
		for(int i =0; i < size; i++){
			System.out.println("Enter element at "+i+" pos ");
			arr[i] = s.nextInt();
		}
		return arr;
	}

	public static void  bubbleSort(int[] input){
		
		for(int i = 0; i < input.length - 1; i++){
			for(int j = 0; j < input.length - i - 1 ; j++){
				if(input[j] > input[j+1]){
					// swap
					int temp = input[j];
					input[j] = input[j+1];
					input[j+1] = temp;
				}
			}
		}
		
	}
	
	public static void printArray(int[] array){
		for(int i = 0; i < array.length; i++){
			System.out.print(array[i]+" ");
		}
		System.out.println();
	}

	public static int sum(int[] input){
		int sum = 0;
		for(int i =0; i < input.length; i++){
			sum += input[i];
		}
		return sum;
	}
	
	
	
	


}
