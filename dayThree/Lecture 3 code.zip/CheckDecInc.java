import java.util.Scanner;


public class CheckDecInc {
	
	
	public static void  a(int a, char ch, String str){
		
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter number of numbers in sequence :");
		int num = s.nextInt();
		int i = 1;
		int prev = Integer.MAX_VALUE ;
		int current;
		boolean isDec = true;
		while(i <= num){
			current = s.nextInt();
			if(isDec && prev < current){
				isDec = false;
			}
			else if(!isDec && prev > current){
				System.out.println("False");
				return;
			}
			prev = current;
			i++;
		}
//		a();
		
//		if(i == num+1){
			System.out.println("True");
//		}
	}

}
