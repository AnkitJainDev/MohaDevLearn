import java.util.Scanner;


public class CheckPrime {
	
	public static boolean isPrime(int num){
		
		int div = 2;
	//	boolean flag = true;
			while(div < num){
				if(num % div == 0){
					//System.out.println("Not Prime");
					//flag = false;
				//	break;
					return false;
				}
				//	System.out.println("Prime");
				div++;
			}
			// return flag;
			return true;
		//	System.out.println();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int num = s.nextInt();
		boolean ans;
		ans = isPrime(num);
		if(ans){
			System.out.println("Prime");
		}
		else{
			System.out.println("Not Prime ");
		}
		

	}

	
	
	
}
