import java.util.Scanner;


public class ArrayUse {

	public static int[] incrementArray(int[] input){
		input = new int[5];
		for(int i = 0; i < input.length; i++){
			input[i]++;
		}
		return input;
	}




	public static int[] takeInput(){
		Scanner s = new Scanner(System.in);
		System.out.println("Enter size ");
		int size = s.nextInt();
		int arr[] = new int[size];
		for(int i =0; i < size; i++){
			System.out.println("Enter element at "+i+" pos ");
			arr[i] = s.nextInt();
		}
		return arr;
	}

	public static void  bubbleSort(int[] input){
		for(int i = 0; i < input.length - 1; i++){
			for(int j = 0; j < input.length - i - 1 ; j++){
				if(input[j] > input[j+1]){
					// swap
					int temp = input[j];
					input[j] = input[j+1];
					input[j+1] = temp;
				}
			}
		}
	}

	public static void printArray(int[] array){
		for(int i = 0; i < array.length; i++){
			System.out.print(array[i]+" ");
		}
		System.out.println();
	}

	public static int sum(int[] input){
		int sum = 0;
		for(int i =0; i < input.length; i++){
			sum += input[i];
		}
		return sum;
	}

	public static void insertionSort(int[] input){
		for(int i = 0; i < input.length; i++){
			int j = i - 1;
			int temp = input[i];
			while(j >= 0 && input[j] > temp){
				input[j+1] = input[j];
				j--;
			}
			input[j+1] = temp;
		}
	}


	public static  int binarySearch(int[] input, int element){

		int start = 0;
		int end = input.length - 1;
		while(start <= end){
			int mid = (start + end)/2;
			
			if(input[mid] == element){
				return mid;
			}
			else if(input[mid] > element){
				end = mid - 1;
			}
			else{
				start = mid + 1;
			}
		}
		return -1;

	}

	public static  int[][] takeInput2D(){
		Scanner s= new Scanner(System.in);
		System.out.println("Enter number of rows :");
		int rows = s.nextInt();
		System.out.println("Enter number of columns :");
		int columns = s.nextInt();
		int[][] array2D = new int[rows][columns];
		for(int i = 0; i < rows; i++){
			for(int j = 0; j < columns; j++){
				System.out.println("Enter value at "+i+" "+j+" column ");
				array2D[i][j] = s.nextInt();
			}
		}
		return array2D;	
	}
	
	
	public static void print2D(int[][] input){
		int rows = input.length;
		int columns = input[0].length;
		for(int i = 0; i < rows; i++){
			for(int j = 0; j < columns; j++){
				System.out.print(input[i][j] +" ");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		int[][] input2d = takeInput2D();
		print2D(input2d);
		
		
//		int input[];
//		input = takeInput(); // 1 2 3 4 
//		Scanner s = new Scanner(System.in);
//		System.out.println("Enter element to be searched ");
//		int element = s.nextInt();
//		System.out.println(binarySearch(input,element ));
	//	insertionSort(input);
		//	bubbleSort(input);

		//	input = new int[5];
		//	System.out.println(input);
	//	printArray(input);
		//		input = incrementArray(input);
		//		printArray(input);
		//	System.out.println("Sum "+ sum(input));
	}



}
