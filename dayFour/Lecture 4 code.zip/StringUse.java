import java.util.Scanner;

public class StringUse {

	public static void printChars(String input){
		for(int i =0; i < input.length(); i++){
			System.out.println(input.charAt(i));
		}
	}
	
	public static void takeInputAndPrint(){
		Scanner s = new Scanner(System.in);
		String str = s.next();
		while(!str.equals("$")){
			System.out.println(str);
			str = s.next();
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String str = "abcdef";
//		String str1 = str;
//		System.out.println(str1);
	//	printChars(str);
	//	takeInputAndPrint();
		Scanner s = new Scanner(System.in);
		s.useDelimiter("\n");
		int value = s.nextInt();
		System.out.println(value);
		String str = s.next();
		System.out.println(str.length());
	//	int arr[] = {1,2,3,4,5};
	
	}

}
