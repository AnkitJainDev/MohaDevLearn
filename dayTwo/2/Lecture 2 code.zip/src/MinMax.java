import java.util.Scanner;


public class MinMax {

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		//		System.out.println("Enter first number");
		//		int first = console.nextInt();
		//		System.out.println("Enter second number");
		//		int second = console.nextInt();
		//		System.out.println("Enter third number");
		//		int third = console.nextInt();
		//	
		//		if(first > second && first > third){
		//			System.out.println(first +" is largest");
		//		}
		//		if(second > first && second > third){
		//			System.out.println(second +" is largest");
		//		}
		//		else {
		//			System.out.println(third +" is largest");
		//		}	
		//		int a = 10;
		//		System.out.println(a);

		//		if(a <= 5 || a++ < 10){
		//			
		//		}
		//		System.out.println(a);

		//		System.out.println("Enter n :");
		//		int n = console.nextInt();
		//		int count = 1;
		//		int sum = 0;
		//		while(count <= n){
		//			int num = console.nextInt();
		//			sum = sum + num;
		//			count++;
		//		}
		//		System.out.println("Sum "+sum);
		//		
		//		int count = 1;
		//		int min = Integer.MAX_VALUE;
		//		while(count <= n){
		//			int num = console.nextInt();
		//			if(num < min){
		//				min = num;
		//			}
		//			count++;
		//		}
		//		System.out.println("Min :"+min);

		System.out.println("Enter number :");
		int num = console.nextInt();
		int div = 2;
	//	boolean flag = true;
		while(div < num){
			if(num % div == 0){
				System.out.println("Not Prime");
				//flag = false;
				return;
			}
			//	System.out.println("Prime");
			div++;
		}
		System.out.println("Prime");
//		if(flag){
//			System.out.println("Prime");
//		}

	}

}
