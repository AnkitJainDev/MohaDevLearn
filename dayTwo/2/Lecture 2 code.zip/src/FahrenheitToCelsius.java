import java.util.Scanner;

public class FahrenheitToCelsius {

	public static void main(String[] args) {

		//		char c1 = 'a',c2 = 'b';
		//		int i1 = c1;
		//		float f1 = (float)4/5;
		//		System.out.println(f1);
		//int a = 3.14;
		//		char c3 =(char) (c1 + c2);
		//		System.out.println(c3);
		//		String s1 = "13";
		//		System.out.println(s1);

		Scanner s = new Scanner(System.in);		
		System.out.println("Enter Minimum value");
		int	minFahrenheitValue = s.nextInt();
	//	s.ne
		System.out.println("Enter Maximum value");
		int maxFahrenheitValue = s.nextInt();

		int currentFahrenheitValue = minFahrenheitValue;
		while(currentFahrenheitValue <= maxFahrenheitValue){
			int celsiusValue = (int)((5.0/9)*(currentFahrenheitValue - 32));
			System.out.println(currentFahrenheitValue +" "+celsiusValue);
			currentFahrenheitValue = currentFahrenheitValue + 20;
		}

	}

}
